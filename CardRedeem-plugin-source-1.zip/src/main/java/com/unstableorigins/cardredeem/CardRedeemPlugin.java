package com.unstableorigins.cardredeem;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * CardRedeem
 *
 * When a player joins, this plugin asks the Discord bot's tiny web API:
 * "has this username claimed any cards that haven't been given yet?"
 *
 * The bot's reply ALREADY includes the exact shulker box + item contents
 * for each card (taken straight from cards.json, which admins edit with
 * !addcard / !editcard on Discord — no separate file on the server to
 * keep in sync). This plugin just builds the real shulker box items and
 * hands them to the player.
 */
public class CardRedeemPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("CardRedeem enabled — checking the Discord bot on player join.");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String username = player.getName();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> checkAndGiveRewards(player, username));
    }

    private void checkAndGiveRewards(Player player, String username) {
        try {
            String baseUrl = getConfig().getString("bot-url", "");
            String apiKey = getConfig().getString("api-key", "");

            if (baseUrl.isEmpty() || baseUrl.contains("your-repl-name")) {
                getLogger().warning("CardRedeem: bot-url is not set in config.yml — skipping check.");
                return;
            }

            String encodedName = URLEncoder.encode(username, StandardCharsets.UTF_8.toString());
            String encodedKey = URLEncoder.encode(apiKey, StandardCharsets.UTF_8.toString());
            String fullUrl = baseUrl + "/api/redeem?ign=" + encodedName + "&key=" + encodedKey;

            HttpURLConnection conn = (HttpURLConnection) new URL(fullUrl).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int status = conn.getResponseCode();
            if (status != 200) {
                getLogger().warning("CardRedeem: bot API returned status " + status + " for " + username);
                return;
            }

            StringBuilder responseText = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) responseText.append(line);
            }

            JSONObject json = new JSONObject(responseText.toString());
            JSONArray rewardsWon = json.optJSONArray("rewards");
            if (rewardsWon == null || rewardsWon.length() == 0) return; // nothing to give

            // Build & give items back on the main server thread (required by Bukkit)
            Bukkit.getScheduler().runTask(this, () -> {
                for (int i = 0; i < rewardsWon.length(); i++) {
                    giveCardRewards(player, rewardsWon.getJSONObject(i));
                }
            });

        } catch (Exception e) {
            getLogger().warning("CardRedeem: failed to check rewards for " + username + " — " + e.getMessage());
        }
    }

    /** Builds every shulker box this reward defines (sent live by the bot) and gives them to the player. */
    private void giveCardRewards(Player player, JSONObject reward) {
        String cardName = reward.optString("cardName", "Unknown Card");
        JSONArray shulkers = reward.optJSONArray("shulkers");

        if (shulkers == null || shulkers.length() == 0) {
            getLogger().warning("CardRedeem: card '" + cardName + "' has no rewards set on Discord (use !editcard ... | rewards | ...).");
            player.sendMessage("§6§l[Cards] §eYou claimed §f" + cardName + "§e, but no in-game reward is set for it yet. Ask an admin to add one.");
            return;
        }

        int givenShulkers = 0;
        for (int i = 0; i < shulkers.length(); i++) {
            JSONObject shulkerDef = shulkers.getJSONObject(i);
            JSONArray items = shulkerDef.optJSONArray("items");
            if (items == null || items.length() == 0) continue;

            ItemStack shulker = buildPackedShulker(items);
            if (shulker == null) continue;

            Map<Integer, ItemStack> leftover = player.getInventory().addItem(shulker);
            if (!leftover.isEmpty()) {
                for (ItemStack drop : leftover.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), drop);
                }
            }
            givenShulkers++;
        }

        if (givenShulkers > 0) {
            player.sendMessage("§6§l[Cards] §aYou received §e" + givenShulkers + " shulker box" + (givenShulkers == 1 ? "" : "es")
                    + "§a of rewards for claiming §e" + cardName + "§a!");
        }
    }

    /** Builds one real, pre-packed shulker box ItemStack from a JSON list of {material, amount, name}. */
    private ItemStack buildPackedShulker(JSONArray items) {
        ItemStack shulkerItem = new ItemStack(Material.SHULKER_BOX);
        ItemMeta meta = shulkerItem.getItemMeta();
        if (!(meta instanceof BlockStateMeta)) return null;

        BlockStateMeta blockMeta = (BlockStateMeta) meta;
        ShulkerBox shulkerState = (ShulkerBox) blockMeta.getBlockState();

        int slot = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject itemDef = items.getJSONObject(i);
            String materialName = itemDef.optString("material", "");
            int amount = itemDef.optInt("amount", 1);
            String customName = itemDef.optString("name", null);

            if (materialName.isEmpty()) continue;

            Material material;
            try {
                material = Material.valueOf(materialName.trim().toUpperCase());
            } catch (IllegalArgumentException ex) {
                getLogger().warning("CardRedeem: unknown material '" + materialName + "' from Discord card data — skipping that item.");
                continue;
            }

            ItemStack item = new ItemStack(material, Math.max(1, amount));
            if (customName != null && !customName.isEmpty()) {
                ItemMeta itemMeta = item.getItemMeta();
                if (itemMeta != null) {
                    itemMeta.setDisplayName("§r" + customName);
                    item.setItemMeta(itemMeta);
                }
            }

            if (slot < shulkerState.getInventory().getSize()) {
                shulkerState.getInventory().setItem(slot, item);
                slot++;
            }
        }

        blockMeta.setBlockState(shulkerState);
        shulkerItem.setItemMeta((ItemMeta) blockMeta);
        return shulkerItem;
    }
}
